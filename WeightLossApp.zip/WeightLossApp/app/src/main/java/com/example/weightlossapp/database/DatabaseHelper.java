package com.example.weightlossapp.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "WeightLossApp.db";
    private static final int DATABASE_VERSION = 7;

    // Users table
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_EMAIL = "email";
    private static final String COLUMN_PASSWORD = "password";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_PHONE = "phone";

    // Weights table
    private static final String TABLE_WEIGHTS = "weights";
    private static final String COLUMN_WEIGHT_ID = "id";
    private static final String COLUMN_DATE = "date";
    private static final String COLUMN_WEIGHT = "weight";

    // Goal table
    private static final String TABLE_GOAL = "goal";
    private static final String COLUMN_GOAL_ID = "id";
    private static final String COLUMN_GOAL_WEIGHT = "goal_weight";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" +
                COLUMN_EMAIL + " TEXT UNIQUE, " +
                COLUMN_PASSWORD + " TEXT," +
                COLUMN_NAME + " TEXT," +
                COLUMN_PHONE + " TEXT)";

        String createWeightsTable = "CREATE TABLE " + TABLE_WEIGHTS + " (" +
                COLUMN_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_DATE + " TEXT, " +
                COLUMN_WEIGHT + " REAL)";

        String createGoalTable = "CREATE TABLE " + TABLE_GOAL + " (" +
                COLUMN_GOAL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_GOAL_WEIGHT + " REAL)";

        db.execSQL(createUsersTable);
        db.execSQL(createWeightsTable);
        db.execSQL(createGoalTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop old tables if they exist and recreate
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOAL);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // Existing user methods
    public boolean addUser(String email, String password, String name, String phone) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_EMAIL, email);
        values.put(COLUMN_PASSWORD, password);
        values.put(COLUMN_NAME, name); //
        values.put(COLUMN_PHONE, phone);

        long result = db.insert(TABLE_USERS, null, values);
        db.close();
        return result != -1;
    }

    public boolean checkUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_USERS +
                " WHERE " + COLUMN_EMAIL + " = ? AND " + COLUMN_PASSWORD + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{email, password});

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }
    public User getUser() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, null, null, null, null, null, null);
        User user = null;
        if (cursor.moveToFirst()) {
            String email = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EMAIL));
            String password = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PASSWORD));
            String name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME));
            String phone = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PHONE));
            user = new User(name, email, password, phone);
        }
        cursor.close();
        db.close();
        return user;
    }

    public boolean updateUser(String newName, String newEmail, String newPhone) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, newName);
        values.put(COLUMN_EMAIL, newEmail);
        values.put(COLUMN_PHONE, newPhone);


        int rows = db.update(TABLE_USERS, values, null, null);
        db.close();
        return rows > 0;
    }


    // Weights table
    public long addWeightEntry(String date, double weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_WEIGHT, weight);

        long result = db.insert(TABLE_WEIGHTS, null, values);
        db.close();
        return result;
    }

    public Cursor getAllWeightEntries() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_WEIGHTS, null, null, null, null, null, null);
    }

    public boolean updateWeightEntry(long entryId, String newDate, double newWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_DATE, newDate);
        values.put(COLUMN_WEIGHT, newWeight);

        int rows = db.update(TABLE_WEIGHTS, values, COLUMN_WEIGHT_ID + "=?", new String[]{String.valueOf(entryId)});
        db.close();
        return rows > 0;
    }

    public boolean deleteWeightEntry(long entryId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_WEIGHTS, COLUMN_WEIGHT_ID + "=?", new String[]{String.valueOf(entryId)});
        db.close();
        return rows > 0;
    }

    // Goal table methods
    public void setGoalWeight(double goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Check if a goal already exists
        Cursor cursor = db.query(TABLE_GOAL, null, null, null, null, null, null);
        ContentValues values = new ContentValues();
        values.put(COLUMN_GOAL_WEIGHT, goalWeight);

        if (cursor.getCount() > 0) {
            // Update the existing row
            db.update(TABLE_GOAL, values, null, null);
        } else {
            // Insert a new row
            db.insert(TABLE_GOAL, null, values);
        }

        cursor.close();
        db.close();
    }

    public double getGoalWeight() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_GOAL, null, null, null, null, null, null);

        double goal = 0.0; // default
        if (cursor.moveToFirst()) {
            goal = cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_GOAL_WEIGHT));
        }
        cursor.close();
        db.close();
        return goal;
    }

    // Helper methods to get start and current weights
    public Double getStartWeight() {
        SQLiteDatabase db = this.getReadableDatabase();
        // Earliest entry = smallest id
        Cursor cursor = db.query(TABLE_WEIGHTS, null, null, null, null, null, COLUMN_WEIGHT_ID + " ASC");
        Double startWeight = null;
        if (cursor.moveToFirst()) {
            startWeight = cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_WEIGHT));
        }
        cursor.close();
        db.close();
        return startWeight;
    }

    public Double getCurrentWeight() {
        SQLiteDatabase db = this.getReadableDatabase();
        // Latest entry = largest id
        Cursor cursor = db.query(TABLE_WEIGHTS, null, null, null, null, null, COLUMN_WEIGHT_ID + " DESC");
        Double currentWeight = null;
        if (cursor.moveToFirst()) {
            currentWeight = cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_WEIGHT));
        }
        cursor.close();
        db.close();
        return currentWeight;
    }

    //Delete
    public boolean deleteUserAccount() {
        SQLiteDatabase db = this.getWritableDatabase();
        int userRows = db.delete(TABLE_USERS, null, null);
        db.delete(TABLE_WEIGHTS, null, null);
        db.delete(TABLE_GOAL, null, null);
        db.close();
        return userRows > 0;
    }

    //Update password
    public boolean updateUserPassword(String oldPassword, String newPassword) {
        User user = getUser();
        if (user == null || !user.password.equals(oldPassword)) {
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_PASSWORD, newPassword);
        int rows = db.update(TABLE_USERS, values, null, null);
        db.close();
        return rows > 0;
    }

    public static class User {
        public String name;
        public String email;
        public String password;
        public String phone;

        public User(String name, String email, String password, String phone) {
            this.name = name;
            this.email = email;
            this.password = password;
            this.phone = phone;
        }
    }
}
