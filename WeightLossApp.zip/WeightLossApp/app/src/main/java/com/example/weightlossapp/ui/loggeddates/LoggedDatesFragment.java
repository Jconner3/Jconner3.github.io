package com.example.weightlossapp.ui.loggeddates;

import android.app.DatePickerDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.weightlossapp.R;
import com.example.weightlossapp.database.DatabaseHelper;

import java.util.Locale;

public class LoggedDatesFragment extends Fragment {

    private DatabaseHelper dbHelper;
    private LinearLayout tableContainer;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_logged_dates, container, false);
        dbHelper = new DatabaseHelper(requireContext());
        tableContainer = view.findViewById(R.id.table_container);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view,
                              @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        loadWeightEntries();
    }

    private void loadWeightEntries() {
        tableContainer.removeAllViews();
        Cursor cursor = dbHelper.getAllWeightEntries();

        if (cursor != null) {
            while (cursor.moveToNext()) {
                long entryId = cursor.getLong(cursor.getColumnIndexOrThrow("id"));
                String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));
                double weight = cursor.getDouble(cursor.getColumnIndexOrThrow("weight"));

                View row = getLayoutInflater().inflate(R.layout.single_row_item, tableContainer, false);

                TextView dateRow = row.findViewById(R.id.dateRow);
                TextView weightRow = row.findViewById(R.id.weightRow);
                ImageButton editButton = row.findViewById(R.id.editButton);
                ImageButton deleteButton = row.findViewById(R.id.deleteButton);

                dateRow.setText(date);
                weightRow.setText(String.valueOf(weight));

                deleteButton.setOnClickListener(v -> {
                    boolean deleted = dbHelper.deleteWeightEntry(entryId);
                    if (deleted) {
                        Toast.makeText(getContext(), "Entry deleted", Toast.LENGTH_SHORT).show();
                        loadWeightEntries();
                    } else {
                        Toast.makeText(getContext(), "Error deleting entry", Toast.LENGTH_SHORT).show();
                    }
                });

                editButton.setOnClickListener(v -> showDatePickerDialog(entryId, weight, date));

                tableContainer.addView(row);
            }
            cursor.close();
        } else {
            Toast.makeText(getContext(), "No entries found", Toast.LENGTH_SHORT).show();
        }
    }

    private void showDatePickerDialog(long entryId, double weight, String currentDate) {
        String[] parts = currentDate.split("-");
        int year = Integer.parseInt(parts[0]);
        int month = Integer.parseInt(parts[1]) - 1;
        int day = Integer.parseInt(parts[2]);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                requireContext(),
                (view, selectedYear, selectedMonth, selectedDay) -> {
                    String newDate = String.format(Locale.getDefault(), "%04d-%02d-%02d",
                            selectedYear, selectedMonth + 1, selectedDay);
                    boolean updated = dbHelper.updateWeightEntry(entryId, newDate, weight);
                    if (updated) {
                        Toast.makeText(getContext(), "Date updated", Toast.LENGTH_SHORT).show();
                        loadWeightEntries();
                    } else {
                        Toast.makeText(getContext(), "Error updating date", Toast.LENGTH_SHORT).show();
                    }
                },
                year, month, day
        );

        datePickerDialog.show();
    }
}
