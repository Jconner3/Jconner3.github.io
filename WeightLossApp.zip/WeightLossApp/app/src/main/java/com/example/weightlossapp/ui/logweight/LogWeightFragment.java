package com.example.weightlossapp.ui.logweight;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.weightlossapp.R;
import com.example.weightlossapp.database.DatabaseHelper;

import java.util.Calendar;
import java.util.Locale;


public class LogWeightFragment extends Fragment {

    private DatePicker datePicker;
    private EditText weightInput;
    private DatabaseHelper dbHelper;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_log_weight, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view,
                              @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        datePicker = view.findViewById(R.id.datePicker);
        weightInput = view.findViewById(R.id.weightInput);
        Button saveWeightButton = view.findViewById(R.id.saveWeightButton);


        dbHelper = new DatabaseHelper(requireContext());

        // Set DatePicker to show the current date by default
        Calendar calendar = Calendar.getInstance();
        datePicker.init(calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH),
                null);

        saveWeightButton.setOnClickListener(v -> {
            String weightStr = weightInput.getText().toString().trim();
            if (TextUtils.isEmpty(weightStr)) {
                Toast.makeText(getContext(), "Please enter a weight", Toast.LENGTH_SHORT).show();
                return;
            }

            double weightVal;
            try {
                weightVal = Double.parseDouble(weightStr);
            } catch (NumberFormatException e) {
                Toast.makeText(getContext(), "Invalid weight value", Toast.LENGTH_SHORT).show();
                return;
            }

            int year = datePicker.getYear();
            int month = datePicker.getMonth() + 1;
            int day = datePicker.getDayOfMonth();


            String dateString = String.format(Locale.getDefault(), "%02d-%02d-%04d", month, day, year);


            long result = dbHelper.addWeightEntry(dateString, weightVal);

            if (result != -1) {
                Toast.makeText(getContext(), "Weight saved successfully", Toast.LENGTH_SHORT).show();
                weightInput.setText("");
            } else {
                Toast.makeText(getContext(), "Error saving weight", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
