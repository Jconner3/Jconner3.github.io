package com.example.weightlossapp.ui.home;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.preference.PreferenceManager;

import com.example.weightlossapp.R;
import com.example.weightlossapp.database.DatabaseHelper;



public class HomeFragment extends Fragment {

    private EditText goalInput;
    private ProgressBar progressBar;
    private TextView progressPercentage;
    private DatabaseHelper dbHelper;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view,
                              @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        dbHelper = new DatabaseHelper(requireContext());

        goalInput = view.findViewById(R.id.goalInput);
        Button modifyGoalButton = view.findViewById(R.id.modifyGoalButton);
        progressBar = view.findViewById(R.id.progressBar);
        progressPercentage = view.findViewById(R.id.progressPercentage);

        double currentGoal = dbHelper.getGoalWeight();
        if (currentGoal != 0.0) {
            goalInput.setText(String.valueOf(currentGoal));
        }

        // Calculate and display progress initially
        updateProgress();

        modifyGoalButton.setOnClickListener(v -> {
            String goalStr = goalInput.getText().toString().trim();
            if (TextUtils.isEmpty(goalStr)) {
                Toast.makeText(getContext(), "Please enter a goal weight", Toast.LENGTH_SHORT).show();
                return;
            }

            double newGoal;
            try {
                newGoal = Double.parseDouble(goalStr);
            } catch (NumberFormatException e) {
                Toast.makeText(getContext(), "Invalid goal weight", Toast.LENGTH_SHORT).show();
                return;
            }

            dbHelper.setGoalWeight(newGoal);
            Toast.makeText(getContext(), "Goal updated", Toast.LENGTH_SHORT).show();

            // Update progress after setting new goal
            updateProgress();
        });
    }
    @Override
    public void onResume() {
        super.onResume();
        updateProgress(); // progress is updated when returning to the Home screen
    }

    private void updateProgress() {
        Double startWeight = dbHelper.getStartWeight();
        Double currentWeight = dbHelper.getCurrentWeight();
        double goalWeight = dbHelper.getGoalWeight();

        if (startWeight == null || currentWeight == null || goalWeight == 0.0) {
            // If we don't have enough data, just show 0%
            progressBar.setProgress(0);
            progressPercentage.setText("0%");
            return;
        }

        if (startWeight.equals(goalWeight)) {
            progressBar.setProgress(100);
            progressPercentage.setText("100%");
            return;
        }

        double numerator = (startWeight - currentWeight);
        double denominator = (startWeight - goalWeight);
        double progress = 0.0;

        if (denominator != 0) {
            progress = (numerator / denominator) * 100;
        }

        if (progress < 0) progress = 0;
        if (progress > 100) progress = 100;

        int intProgress = (int) Math.round(progress);
        progressBar.setProgress(intProgress);
        progressPercentage.setText(intProgress + "%");

        if (intProgress == 100) {
            checkAndSendSMSIfEnabled();
    }
}
    private void checkAndSendSMSIfEnabled() {
        DatabaseHelper.User user = dbHelper.getUser();
        if (user == null || user.phone == null || user.phone.isEmpty()) {
            return;
        }

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(requireContext());
        boolean smsEnabled = prefs.getBoolean("sms_notifications", false);

        if (smsEnabled && ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            sendSMS(user.phone, "Congratulations! You've reached your goal weight!");
        }

    }
    private void sendSMS(String phoneNumber, String message) {
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNumber, null, message, null, null);
    }
}
