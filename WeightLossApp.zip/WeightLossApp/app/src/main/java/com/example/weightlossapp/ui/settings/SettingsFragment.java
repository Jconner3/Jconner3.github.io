package com.example.weightlossapp.ui.settings;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.navigation.fragment.NavHostFragment;
import androidx.preference.Preference;
import androidx.preference.PreferenceFragmentCompat;

import com.example.weightlossapp.MainActivity;
import com.example.weightlossapp.R;

public class SettingsFragment extends PreferenceFragmentCompat {

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        setPreferencesFromResource(R.xml.root_preferences, rootKey);

        Preference profilePref = findPreference("profile");
        Preference notificationPref = findPreference("notification_preferences");
        Preference dataPrivacyPref = findPreference("data_privacy");
        Preference logoutPref = findPreference("logout");

        if (profilePref != null) {
            profilePref.setOnPreferenceClickListener(pref -> {
                NavHostFragment.findNavController(this)
                        .navigate(R.id.action_settingsFragment_to_ProfileFragment);
                return true;
            });
        }

        if (notificationPref != null) {
            notificationPref.setOnPreferenceClickListener(pref -> {
                NavHostFragment.findNavController(this)
                        .navigate(R.id.action_settingsFragment_to_NotificationPreferencesFragment);
                return true;
            });
        }

        if (dataPrivacyPref != null) {
            dataPrivacyPref.setOnPreferenceClickListener(pref -> {
                NavHostFragment.findNavController(this)
                        .navigate(R.id.action_settingsFragment_to_DataPrivacyFragment);
                return true;
            });
        }

        if (logoutPref != null) {
            logoutPref.setOnPreferenceClickListener(pref -> {
                new AlertDialog.Builder(requireContext())
                        .setTitle("Logout")
                        .setMessage("Are you sure you want to logout?")
                        .setPositiveButton("Yes", (dialog, which) -> {
                            requireActivity()
                                    .getSharedPreferences("user_session", Context.MODE_PRIVATE)
                                    .edit()
                                    .clear()
                                    .apply();
                            Toast.makeText(requireContext(), "Logged out successfully", Toast.LENGTH_SHORT).show();

                            Intent intent = new Intent(requireContext(), MainActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intent);
                        })
                        .setNegativeButton("No", null)
                        .show();
                return true;
            });
        }
    }
}