package com.example.weightlossapp.ui.signup;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.weightlossapp.MainActivity;
import com.example.weightlossapp.R;
import com.example.weightlossapp.database.DatabaseHelper;
import com.example.weightlossapp.util.CryptoUtil;


public class SignUpActivity extends AppCompatActivity {

    private EditText nameInput, emailInput, passwordInput, confirmPasswordInput, phoneInput;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);


        nameInput = findViewById(R.id.nameInput);
        emailInput = findViewById(R.id.emailInput);
        passwordInput = findViewById(R.id.passwordInput);
        confirmPasswordInput = findViewById(R.id.confirmPasswordInput);
        phoneInput = findViewById(R.id.phoneInput);
        Button signUpButton = findViewById(R.id.signUpButton);
        TextView backToLoginText = findViewById(R.id.backToLoginText);


        // Sign Up Button Click Listener
        signUpButton.setOnClickListener(v -> {
            String name = nameInput.getText().toString().trim();
            String email = emailInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();
            String confirmPassword = confirmPasswordInput.getText().toString().trim();
            String phone = phoneInput.getText().toString().trim();

            if (TextUtils.isEmpty(name) || TextUtils.isEmpty(email) || TextUtils.isEmpty(password) || TextUtils.isEmpty(confirmPassword)) {
                Toast.makeText(SignUpActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            if (password.length() < 6 || !password.matches(".*\\d.*")) {
                Toast.makeText(SignUpActivity.this, "Password must be at least 6 characters and include a number", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!password.equals(confirmPassword)) {
                Toast.makeText(SignUpActivity.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                return;
            }
            // Create salt and store it once on sign up
            SharedPreferences prefs = getSharedPreferences("secure_prefs", MODE_PRIVATE);
            byte[] salt = CryptoUtil.genSalt(16);
            prefs.edit().putString("db_salt", CryptoUtil.b64(salt)).apply();

// Derive the SQLCipher passphrase from the chosen password
            char[] passphrase = CryptoUtil.derivePassphrase(password, salt);

// Open encrypted DB with that passphrase and create the user
            DatabaseHelper databaseHelper = new DatabaseHelper(SignUpActivity.this, passphrase);
            boolean success = databaseHelper.addUser(email, password, name, phone);

            if (success) {
                Toast.makeText(SignUpActivity.this, "Account created successfully", Toast.LENGTH_SHORT).show();
                finish(); // returns to Login; on login you’ll derive again and open the DB
            } else {
                Toast.makeText(SignUpActivity.this, "Account already exists", Toast.LENGTH_SHORT).show();
            }

        });

        // Back to login click Listener
        backToLoginText.setOnClickListener(v -> {
            Intent intent = new Intent(SignUpActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        });
    }
}
