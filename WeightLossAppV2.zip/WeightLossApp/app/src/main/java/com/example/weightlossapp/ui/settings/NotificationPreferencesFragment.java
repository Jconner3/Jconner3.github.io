package com.example.weightlossapp.ui.settings;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;
import androidx.preference.PreferenceFragmentCompat;
import androidx.preference.SwitchPreferenceCompat;

import com.example.weightlossapp.R;

public class NotificationPreferencesFragment extends PreferenceFragmentCompat {
    private ActivityResultLauncher<String> requestSendSmsPermissionLauncher;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestSendSmsPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                isGranted -> {
                    SwitchPreferenceCompat smsPref = findPreference("sms_notifications");
                    if (smsPref != null) {
                        if (isGranted) {
                            smsPref.setChecked(true);
                            Toast.makeText(getContext(), "SMS notifications enabled", Toast.LENGTH_SHORT).show();
                        } else {
                            smsPref.setChecked(false);
                            Toast.makeText(getContext(), "Permission denied, SMS not enabled", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
        );
    }

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        setPreferencesFromResource(R.xml.notification_preferences, rootKey);

        SwitchPreferenceCompat smsPref = findPreference("sms_notifications");
        if (smsPref != null) {
            smsPref.setOnPreferenceChangeListener((preference, newValue) -> {
                boolean enabled = (boolean) newValue;
                if (enabled) {
                    if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.SEND_SMS)
                            != PackageManager.PERMISSION_GRANTED) {

                        requestSendSmsPermissionLauncher.launch(Manifest.permission.SEND_SMS);

                        return false;
                    } else {
                        Toast.makeText(getContext(), "SMS notifications enabled", Toast.LENGTH_SHORT).show();
                        return true;
                    }
                } else {
                    Toast.makeText(getContext(), "SMS notifications disabled", Toast.LENGTH_SHORT).show();
                    return true;
                }
            });
        }

    }
}


