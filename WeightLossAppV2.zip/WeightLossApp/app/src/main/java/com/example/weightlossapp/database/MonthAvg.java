package com.example.weightlossapp.database;

// simple holder for average weight per month
public class MonthAvg {
    public final String month;
    public final double average;

    public MonthAvg(String month, double average) {
        this.month = month;
        this.average = average;
    }
}