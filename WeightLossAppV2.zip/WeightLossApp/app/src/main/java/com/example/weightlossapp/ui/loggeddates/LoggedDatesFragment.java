package com.example.weightlossapp.ui.loggeddates;

import android.app.DatePickerDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.PopupMenu;
import androidx.appcompat.widget.SwitchCompat;
import androidx.fragment.app.Fragment;

import com.example.weightlossapp.R;
import com.example.weightlossapp.database.DatabaseHelper;
import com.example.weightlossapp.database.MonthAvg;
import com.google.android.material.snackbar.Snackbar;

import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class LoggedDatesFragment extends Fragment {

    private DatabaseHelper dbHelper;
    private LinearLayout tableContainer;
    private LinearLayout monthlyAvgContainer;
    private Spinner filterSpinner;
    private SwitchCompat sortSwitch;

    private boolean newestFirst = true;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_logged_dates, container, false); // inflate the logged dates screen layout
        dbHelper = new DatabaseHelper(requireContext());
        monthlyAvgContainer = view.findViewById(R.id.monthly_avg_container); // top summary list of monthly averages
        tableContainer = view.findViewById(R.id.table_container); // scrollable list/table of individual entries
        filterSpinner = view.findViewById(R.id.filterSpinner); // dropdown filter for time range
        sortSwitch = view.findViewById(R.id.sortSwitch); // switch to choose sort: newest first vs oldest first

        return view;

    }

    @Override
    public void onViewCreated(@NonNull View view,
                              @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        // when the sort switch changes, reload the list
        sortSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            newestFirst = isChecked;
            loadWeightEntries();
        });
        // when the filter changes ("All / 30 / 7"), reload
        filterSpinner.setOnItemSelectedListener(new SimpleItemSelected(() -> loadWeightEntries()));

        refreshLists();
    }

    // refresh both the monthly averages and the individual log entries
    private void refreshLists() {
        loadMonthlyAverages();
        loadWeightEntries();
    }

    // build the "Monthly Averages" section at the top
    private void loadMonthlyAverages() {
        monthlyAvgContainer.removeAllViews();
        List<MonthAvg> avgs = dbHelper.getMonthlyAverages();
        // if there is no data yet, show a simple message
        if (avgs == null || avgs.isEmpty()) {
            TextView empty = new TextView(requireContext());
            empty.setText(getString(R.string.no_monthly_data));
            monthlyAvgContainer.addView(empty);
            return;
        }

        LayoutInflater inflater = getLayoutInflater();
        for (MonthAvg m : avgs) {
            View row = inflater.inflate(R.layout.row_month_avg, monthlyAvgContainer, false);
            TextView month = row.findViewById(R.id.monthLabel);
            TextView avg = row.findViewById(R.id.avgLabel);

            month.setText(m.month);


            avg.setText(String.format(Locale.getDefault(), "%.1f", m.average));

            monthlyAvgContainer.addView(row);
        }
    }

    // build the full list of logged entries (date + weight), grouped by month
    private void loadWeightEntries() {
        tableContainer.removeAllViews();
        // based on filterSpinner, we might limit to last 7 or 30 days
        String cutoff = computeCutoffIso(); // null for "All"
        try (Cursor cursor = dbHelper.getWeightEntries(cutoff, newestFirst)) {
            if (cursor == null || !cursor.moveToFirst()) {
                Toast.makeText(getContext(), R.string.no_entries_found, Toast.LENGTH_SHORT).show();
                return;
            }

            LayoutInflater inflater = getLayoutInflater();
            String lastMonthKey = null;

            do {
                long entryId = cursor.getLong(cursor.getColumnIndexOrThrow("id"));
                String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));      // YYYY-MM-DD
                double weight = cursor.getDouble(cursor.getColumnIndexOrThrow("weight"));

                // month header when month changes
                String monthKey = date.substring(0, 7); // YYYY-MM
                if (!monthKey.equals(lastMonthKey)) {
                    View header = inflater.inflate(R.layout.row_month_header, tableContainer, false);
                    TextView hdr = header.findViewById(R.id.monthHeader);
                    // display as "Oct 2025"
                    String pretty = formatMonthPretty(monthKey);
                    hdr.setText(pretty);
                    tableContainer.addView(header);
                    lastMonthKey = monthKey;
                }
                // now add the actual entry row (date + weight)
                View row = inflater.inflate(R.layout.single_row_item, tableContainer, false);
                TextView dateRow = row.findViewById(R.id.dateRow);
                TextView weightRow = row.findViewById(R.id.weightRow);
                // display date as MM-DD-YYYY
                dateRow.setText(dateToDisplay(date));
                weightRow.setText(String.valueOf(weight));

                // tap the weight to edit it inline
                weightRow.setOnClickListener(v -> promptEditWeight(entryId, date, weight));

                // long-press row to open popup menu (edit date / edit weight / delete)
                row.setOnLongClickListener(v -> {
                    PopupMenu menu =
                            new PopupMenu(requireContext(), v);

                    menu.getMenu().add(getString(R.string.edit_date))
                            .setOnMenuItemClickListener(i -> { showDatePickerDialog(entryId, weight, date); return true; });

                    menu.getMenu().add(getString(R.string.edit_weight))
                            .setOnMenuItemClickListener(i -> { promptEditWeight(entryId, date, weight); return true; });

                    menu.getMenu().add(getString(R.string.delete))
                            .setOnMenuItemClickListener(i -> { confirmAndDelete(entryId, date, weight, row); return true; });

                    menu.show();
                    return true;
                });

                tableContainer.addView(row);
            } while (cursor.moveToNext());
        }
    }

    // figure out which cutoff date to use based on the spinner selection
    // position 0 = All, 1 = last 30 days, 2 = last 7 days
    @Nullable
    private String computeCutoffIso() {
        int pos = filterSpinner.getSelectedItemPosition(); // 0=All,1=30,2=7
        if (pos == 0) return null;

        int days = (pos == 1) ? 30 : 7;
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -days);
        int y = cal.get(Calendar.YEAR);
        int m = cal.get(Calendar.MONTH) + 1;
        int d = cal.get(Calendar.DAY_OF_MONTH);
        return String.format(Locale.US, "%04d-%02d-%02d", y, m, d);
    }
    // ask user to confirm before deleting an entry
    // after delete, show Snackbar with UNDO option
    private void confirmAndDelete(long entryId, String date, double weight, View anchor) {
        new androidx.appcompat.app.AlertDialog.Builder(requireContext())
                .setTitle(R.string.confirm_delete_title)
                .setMessage(R.string.confirm_delete_msg)
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.delete, (dlg, which) -> {
                    boolean deleted = dbHelper.deleteWeightEntry(entryId);
                    if (deleted) {
                        Snackbar.make(anchor, R.string.entry_deleted, Snackbar.LENGTH_LONG)
                                .setAction(R.string.undo, v -> {
                                    dbHelper.addWeightEntry(date, weight);
                                    refreshLists();
                                })
                                .show();
                        refreshLists();
                    } else {
                        Toast.makeText(getContext(), R.string.error_deleting_entry, Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }
    // dialog to edit the weight value in an existing entry
    private void promptEditWeight(long entryId, String date, double currentWeight) {
        final android.widget.EditText input = new android.widget.EditText(requireContext());
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER
                | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setText(String.valueOf(currentWeight));
        input.setSelection(input.getText().length());

        new androidx.appcompat.app.AlertDialog.Builder(requireContext())
                .setTitle(R.string.edit_weight)
                .setView(input)
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(android.R.string.ok, (d, w) -> {
                    double newW;
                    try {
                        newW = Double.parseDouble(input.getText().toString().trim());
                    } catch (NumberFormatException e) {
                        Toast.makeText(getContext(), R.string.invalid_weight_value, Toast.LENGTH_SHORT).show();
                        return;
                    }

                    boolean ok = dbHelper.updateWeightEntry(entryId, date, newW);
                    if (ok) {
                        com.google.android.material.snackbar.Snackbar
                                .make(requireView(), getString(R.string.weight_saved), com.google.android.material.snackbar.Snackbar.LENGTH_LONG)
                                .setAction(R.string.undo, v1 -> {
                                    dbHelper.updateWeightEntry(entryId, date, currentWeight);
                                    refreshLists();
                                })
                                .show();
                        refreshLists();
                    } else {
                        Toast.makeText(getContext(), R.string.error_saving_weight, Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }
    // show a DatePicker to change the date for an entry
    private void showDatePickerDialog(long entryId, double weight, String currentDate) {
        String[] parts = currentDate.split("-");
        int year = Integer.parseInt(parts[0]);
        int month = Integer.parseInt(parts[1]) - 1;
        int day = Integer.parseInt(parts[2]);

        DatePickerDialog dlg = new DatePickerDialog(
                requireContext(),
                (v, y, m, d) -> {
                    String newDate = String.format(Locale.getDefault(), "%04d-%02d-%02d", y, m + 1, d);
                    boolean updated = dbHelper.updateWeightEntry(entryId, newDate, weight);
                    if (updated) refreshLists();
                },
                year, month, day
        );
        dlg.show();
    }

    // turn "2025-10" into "Oct 2025"
    private String formatMonthPretty(String yyyyDashMm) {
        int y = Integer.parseInt(yyyyDashMm.substring(0, 4));
        int m = Integer.parseInt(yyyyDashMm.substring(5, 7));
        java.text.DateFormatSymbols dfs = new java.text.DateFormatSymbols(Locale.getDefault());
        String monthName = dfs.getMonths()[m - 1];
        return monthName.substring(0, 1).toUpperCase(Locale.getDefault())
                + monthName.substring(1) + " " + y;
    }

    // turn "2025-10-26" into "10-26-2025"
    private String dateToDisplay(String yyyyMmDd) {
        String mm = yyyyMmDd.substring(5, 7);
        String dd = yyyyMmDd.substring(8, 10);
        String yyyy = yyyyMmDd.substring(0, 4);
        return mm + "-" + dd + "-" + yyyy;
    }

    // listener helper to not repeat boilerplate for spinner selection
    static class SimpleItemSelected implements android.widget.AdapterView.OnItemSelectedListener {
        private final Runnable onSelect;

        SimpleItemSelected(Runnable onSelect) {
            this.onSelect = onSelect;
        }

        @Override
        public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
            onSelect.run();
        }

        @Override
        public void onNothingSelected(android.widget.AdapterView<?> parent) {
        }
    }

}