package com.example.weightlossapp.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import androidx.annotation.Nullable;

import net.sqlcipher.database.SQLiteDatabase;
import net.sqlcipher.database.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * DatabaseHelper

 * This class manages all local database operations for the WeightLossApp.
 * It uses SQLCipher's encrypted SQLite database to store:
 *  - User account info (users table)
 *  - Weight log entries over time (weights table)
 *  - Target/goal weight (goal table)

 * Notes:
 *  - The database is encrypted using SQLCipher. Access requires a passphrase.
 *  - Only one user profile is assumed in this app at a time.
 */


public class DatabaseHelper extends SQLiteOpenHelper {

    // Name and version of the encrypted database file
    private static final String DATABASE_NAME = "WeightLossApp.db";
    private static final int DATABASE_VERSION = 7;

    // Users table
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_EMAIL = "email";
    private static final String COLUMN_PASSWORD = "password";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_PHONE = "phone";

    // Weights table
    private static final String TABLE_WEIGHTS = "weights";
    private static final String COLUMN_WEIGHT_ID = "id";
    private static final String COLUMN_DATE = "date";
    private static final String COLUMN_WEIGHT = "weight";

    // Goal table
    private static final String TABLE_GOAL = "goal";
    private static final String COLUMN_GOAL_ID = "id";
    private static final String COLUMN_GOAL_WEIGHT = "goal_weight";

    // The SQLCipher key material used to open the encrypted DB
    private final char[] passphrase;

    // Constructor when we already have the encryption key (signup/login flow)
    public DatabaseHelper(Context context, char[] passphrase) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        SQLiteDatabase.loadLibs(context.getApplicationContext());
        this.passphrase = passphrase;
    }
    // Convenience constructor that reads the key from DbSession
    public DatabaseHelper(Context context) {
        this(context, DbSession.get());
        if (this.passphrase == null) {
            throw new IllegalStateException("No DB passphrase in session. Login first.");
        }
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        // Table for user account info
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" +
                COLUMN_EMAIL + " TEXT UNIQUE, " +
                COLUMN_PASSWORD + " TEXT," +
                COLUMN_NAME + " TEXT," +
                COLUMN_PHONE + " TEXT)";

        // Table for weight entries over time
        String createWeightsTable = "CREATE TABLE " + TABLE_WEIGHTS + " (" +
                COLUMN_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_DATE + " TEXT, " +
                COLUMN_WEIGHT + " REAL)";

        // Table to store the user's goal weight
        String createGoalTable = "CREATE TABLE " + TABLE_GOAL + " (" +
                COLUMN_GOAL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_GOAL_WEIGHT + " REAL)";

        db.execSQL(createUsersTable);
        db.execSQL(createWeightsTable);
        db.execSQL(createGoalTable);

        // Index on date for faster queries by date range
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_weights_date ON " + TABLE_WEIGHTS + " (" + COLUMN_DATE + ")");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop old tables if they exist and recreate
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOAL);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // Existing user methods
    public boolean addUser(String email, String password, String name, String phone) {
        SQLiteDatabase db = this.getWritableDatabase(passphrase);
        ContentValues values = new ContentValues();
        values.put(COLUMN_EMAIL, email);
        values.put(COLUMN_PASSWORD, password);
        values.put(COLUMN_NAME, name); //
        values.put(COLUMN_PHONE, phone);

        long result = db.insert(TABLE_USERS, null, values);
        db.close();
        return result != -1; // insert returns -1 on failure
    }

    // check if a user exists with given email/password
    public boolean checkUser(String email, String password) {
        try {
            SQLiteDatabase db = this.getReadableDatabase(passphrase);
            String query = "SELECT * FROM " + TABLE_USERS +
                    " WHERE " + COLUMN_EMAIL + " = ? AND " + COLUMN_PASSWORD + " = ?";
            Cursor cursor = db.rawQuery(query, new String[]{email, password});
            boolean exists = cursor.getCount() > 0;
            cursor.close();
            db.close();
            return exists;
        } catch (Exception e) {
            // Wrong key or DB not initialized
            return false;
        }

    }

    // get the single stored user
    public User getUser() {
        SQLiteDatabase db = this.getReadableDatabase(passphrase);
        Cursor cursor = db.query(TABLE_USERS, null, null, null, null, null, null);
        User user = null;
        if (cursor.moveToFirst()) {
            String email = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EMAIL));
            String password = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PASSWORD));
            String name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME));
            String phone = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PHONE));
            user = new User(name, email, password, phone);
        }
        cursor.close();
        db.close();
        return user;
    }

    // update user info (name, email, phone)
    public boolean updateUser(String newName, String newEmail, String newPhone) {
        SQLiteDatabase db = this.getWritableDatabase(passphrase);
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, newName);
        values.put(COLUMN_EMAIL, newEmail);
        values.put(COLUMN_PHONE, newPhone);


        int rows = db.update(TABLE_USERS, values, null, null);
        db.close();
        return rows > 0;
    }


    // Weights table, insert a new weight entry for a given date
    public long addWeightEntry(String date, double weight) {
        SQLiteDatabase db = this.getWritableDatabase(passphrase);
        ContentValues values = new ContentValues();
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_WEIGHT, weight);

        long result = db.insert(TABLE_WEIGHTS, null, values);
        db.close();
        return result;
    }

    // update an existing weight entry by id
    public boolean updateWeightEntry(long entryId, String newDate, double newWeight) {
        SQLiteDatabase db = this.getWritableDatabase(passphrase);
        ContentValues values = new ContentValues();
        values.put(COLUMN_DATE, newDate);
        values.put(COLUMN_WEIGHT, newWeight);

        int rows = db.update(TABLE_WEIGHTS, values, COLUMN_WEIGHT_ID + "=?", new String[]{String.valueOf(entryId)});
        db.close();
        return rows > 0;
    }

    // delete a weight entry by id
    public boolean deleteWeightEntry(long entryId) {
        SQLiteDatabase db = this.getWritableDatabase(passphrase);
        int rows = db.delete(TABLE_WEIGHTS, COLUMN_WEIGHT_ID + "=?", new String[]{String.valueOf(entryId)});
        db.close();
        return rows > 0;
    }

    // get the saved goal weight (returns 0.0 if none set yet)
    public double getGoalWeight() {
        SQLiteDatabase db = this.getReadableDatabase(passphrase);
        Cursor cursor = db.query(TABLE_GOAL, null, null, null, null, null, null);

        double goal = 0.0; // default
        if (cursor.moveToFirst()) {
            goal = cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_GOAL_WEIGHT));
        }
        cursor.close();
        db.close();
        return goal;
    }

    // Goal table methods
    public void setGoalWeight(double goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase(passphrase);

        // Check if a goal already exists
        Cursor cursor = db.query(TABLE_GOAL, null, null, null, null, null, null);
        ContentValues values = new ContentValues();
        values.put(COLUMN_GOAL_WEIGHT, goalWeight);

        if (cursor.getCount() > 0) {
            // Update the existing row
            db.update(TABLE_GOAL, values, null, null);
        } else {
            // Insert a new row
            db.insert(TABLE_GOAL, null, values);
        }

        cursor.close();
        db.close();
    }

    // get the earliest (first) recorded weight
    public Double getStartWeight() {
        SQLiteDatabase db = this.getReadableDatabase(passphrase);
        // Earliest entry = smallest id
        Cursor cursor = db.query(TABLE_WEIGHTS, null, null, null, null, null, COLUMN_WEIGHT_ID + " ASC");
        Double startWeight = null;
        if (cursor.moveToFirst()) {
            startWeight = cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_WEIGHT));
        }
        cursor.close();
        db.close();
        return startWeight;
    }

    // get the most recent recorded weight
    public Double getCurrentWeight() {
        SQLiteDatabase db = this.getReadableDatabase(passphrase);
        // Latest entry = largest id
        Cursor cursor = db.query(TABLE_WEIGHTS, null, null, null, null, null, COLUMN_WEIGHT_ID + " DESC");
        Double currentWeight = null;
        if (cursor.moveToFirst()) {
            currentWeight = cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_WEIGHT));
        }
        cursor.close();
        db.close();
        return currentWeight;
    }

    // delete all stored user data
    public boolean deleteUserAccount() {
        SQLiteDatabase db = this.getWritableDatabase(passphrase);
        int userRows = db.delete(TABLE_USERS, null, null);
        db.delete(TABLE_WEIGHTS, null, null);
        db.delete(TABLE_GOAL, null, null);
        db.close();
        return userRows > 0;
    }

    //Update password
    public boolean updateUserPassword(String oldPassword, String newPassword) {
        User user = getUser();
        if (user == null || !user.password.equals(oldPassword))
            return false;

        SQLiteDatabase db = this.getWritableDatabase(passphrase);
        ContentValues values = new ContentValues();
        values.put(COLUMN_PASSWORD, newPassword);
        int rows = db.update(TABLE_USERS, values, null, null);
        db.close();
        return rows > 0;
    }

    // build a list of average weights per month
    public List<MonthAvg> getMonthlyAverages() {
        List<MonthAvg> results = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase(passphrase);

        String sql =
                "SELECT " +
                        "CASE " +
                        "  WHEN length(" + COLUMN_DATE + ") = 10 " +
                        "       AND substr(" + COLUMN_DATE + ",5,1)='-' " +
                        "       AND substr(" + COLUMN_DATE + ",8,1)='-' " +
                        "    THEN strftime('%m-%Y', " + COLUMN_DATE + ") " +
                        "  ELSE substr(" + COLUMN_DATE + ",1,2) || '-' || substr(" + COLUMN_DATE + ",7,4) " +
                        "END AS month_key, " +
                        "AVG(" + COLUMN_WEIGHT + ") AS avg_weight " +
                        "FROM " + TABLE_WEIGHTS + " " +
                        "GROUP BY month_key " +
                        // sort by year then month to keep chronological order
                        "ORDER BY substr(month_key, 4, 4), substr(month_key, 1, 2);";

        Cursor c = db.rawQuery(sql, null);
        while (c.moveToNext()) {
            String month = c.getString(c.getColumnIndexOrThrow("month_key"));
            double avg = c.getDouble(c.getColumnIndexOrThrow("avg_weight"));
            results.add(new MonthAvg(month, avg));
        }
        c.close();
        db.close();
        return results;
    }

    public Cursor getWeightEntries(@Nullable String minIsoDate, boolean newestFirst) {
        SQLiteDatabase db = this.getReadableDatabase(passphrase);
        String where = (minIsoDate == null) ? "" : " WHERE " + COLUMN_DATE + " >= ?";
        String order = " ORDER BY " + COLUMN_DATE + (newestFirst ? " DESC" : " ASC")
                + ", " + COLUMN_WEIGHT_ID + (newestFirst ? " DESC" : " ASC");
        String sql = "SELECT " + COLUMN_WEIGHT_ID + " AS id, "
                + COLUMN_DATE + " AS date, "
                + COLUMN_WEIGHT + " AS weight "
                + "FROM " + TABLE_WEIGHTS + where + order;
        return (minIsoDate == null) ? db.rawQuery(sql, null)
                : db.rawQuery(sql, new String[]{minIsoDate});
    }


    public Cursor getWeightDatesForMonth(int year, int monthOneToTwelve) {
        String prefix = String.format(java.util.Locale.US, "%04d-%02d", year, monthOneToTwelve);
    
        net.sqlcipher.database.SQLiteDatabase db = this.getReadableDatabase(passphrase);

        return db.rawQuery(
                "SELECT " + "date" + " AS date FROM " + "weights" + " WHERE " + "date" + " LIKE ? || '%'",
                new String[]{prefix}
        );
    }


    // simple data class for the single user
    public static class User {
        public String name;
        public String email;
        public String password;
        public String phone;

        public User(String name, String email, String password, String phone) {
            this.name = name;
            this.email = email;
            this.password = password;
            this.phone = phone;
        }

    }

}



