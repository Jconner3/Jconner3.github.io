package com.example.weightlossapp.ui.home;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import androidx.preference.PreferenceManager;

import com.example.weightlossapp.R;
import com.example.weightlossapp.database.DatabaseHelper;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.progressindicator.LinearProgressIndicator;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;


public class HomeFragment extends Fragment {

    private EditText goalInput;
    private LinearProgressIndicator progressBar;
    private TextView progressPercentage;
    private TextView welcomeMessage;
    private View progressCard;
    private View emptyStateCard;
    private Button logNowButton;
    private DatabaseHelper dbHelper;
    private TextView statStart;
    private TextView statCurrent;
    private TextView statGoal;
    private TextView statRemaining;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view,
                              @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        dbHelper = new DatabaseHelper(requireContext());

        // header
        welcomeMessage = view.findViewById(R.id.welcomeMessage);


        // cards
        progressCard = view.findViewById(R.id.progressCard);
        emptyStateCard = view.findViewById(R.id.emptyStateCard);
        logNowButton = view.findViewById(R.id.logNowButton);

        goalInput = view.findViewById(R.id.goalInput);
        Button modifyGoalButton = view.findViewById(R.id.modifyGoalButton);
        progressBar = view.findViewById(R.id.progressBar);
        progressPercentage = view.findViewById(R.id.progressPercentage);

        // live stat labels under the progress card
        statStart = view.findViewById(R.id.statStart);
        statCurrent = view.findViewById(R.id.statCurrent);
        statGoal = view.findViewById(R.id.statGoal);
        statRemaining = view.findViewById(R.id.statRemaining);

        // personalize header
        DatabaseHelper.User u = dbHelper.getUser();
        String name = (u != null && u.name != null && !u.name.isEmpty())
                ? u.name.split("\\s+")[0] : getString(R.string.default_user_name);
        welcomeMessage.setText(getString(R.string.home_greeting, name));



        // "Log now" button inside the empty-state card:
        logNowButton.setOnClickListener(v -> {
            BottomNavigationView bnv = requireActivity().findViewById(R.id.bottomNavigation);
            if (bnv != null) {
                bnv.setSelectedItemId(R.id.nav_log_weight);
            } else {
                NavHostFragment.findNavController(this).navigate(R.id.nav_log_weight);
            }
        });

        // load saved goal weight from DB into the input field
        double currentGoal = dbHelper.getGoalWeight();
        if (currentGoal != 0.0) {
            goalInput.setText(String.valueOf(currentGoal));
        }

        // Calculate and display progress initially
        updateProgress();

        // when user taps "Update Goal", save new target weight and refresh UI
        modifyGoalButton.setOnClickListener(v -> {
            String goalStr = goalInput.getText().toString().trim();
            if (TextUtils.isEmpty(goalStr)) {
                Toast.makeText(getContext(), "Please enter a goal weight", Toast.LENGTH_SHORT).show();
                return;
            }

            double newGoal;
            try {
                newGoal = Double.parseDouble(goalStr);
            } catch (NumberFormatException e) {
                Toast.makeText(getContext(), "Invalid goal weight", Toast.LENGTH_SHORT).show();
                return;
            }

            dbHelper.setGoalWeight(newGoal);
            Toast.makeText(getContext(), "Goal updated", Toast.LENGTH_SHORT).show();

            // Update progress after setting new goal
            updateProgress();
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        updateProgress(); // progress is updated when returning to the Home screen
    }

    private void updateProgress() {
        Double startWeight = dbHelper.getStartWeight();
        Double currentWeight = dbHelper.getCurrentWeight();
        double goalWeight = dbHelper.getGoalWeight();

        // Empty state: no starting entry yet
        if (startWeight == null) {
            progressCard.setVisibility(View.GONE);
            emptyStateCard.setVisibility(View.VISIBLE);
            // still update displayed labels with dashes
            applyLiveLabels(null, currentWeight, goalWeight);
            progressBar.setIndeterminate(false);
            progressBar.setProgressCompat(0, false);
            progressPercentage.setText("0%");
            return;
        } else {
            emptyStateCard.setVisibility(View.GONE);
            progressCard.setVisibility(View.VISIBLE);
        }

        applyLiveLabels(startWeight, currentWeight, goalWeight);

        // if we can't compute % yet, just show 0%
        if (currentWeight == null || goalWeight == 0.0) {
            progressBar.setIndeterminate(false);
            progressBar.setProgressCompat(0, false);
            progressPercentage.setText("0%");
            return;
        }
        // if start weight == goal weight, treat as 100% done
        if (startWeight.equals(goalWeight)) {
            progressBar.setProgressCompat(100, true);
            progressPercentage.setText("100%");
            checkAndSendSMSIfEnabled();
            return;
        }

        // calculate progress toward goal as a percent
        double numerator = (startWeight - currentWeight);
        double denominator = (startWeight - goalWeight);
        double progress = (denominator != 0) ? (numerator / denominator) * 100.0 : 0.0;
        if (progress < 0) progress = 0;
        if (progress > 100) progress = 100;

        // update progress bar and % label
        int intProgress = (int) Math.round(progress);
        progressBar.setIndeterminate(false);
        progressBar.setProgressCompat(intProgress, true);
        progressPercentage.setText(intProgress + "%");

        if (intProgress == 100) {
            checkAndSendSMSIfEnabled();
        }
    }

    private void applyLiveLabels(@Nullable Double startWeight,
                                 @Nullable Double currentWeight,
                                 double goalWeight) {

        // format numbers to 1 decimal place, or use dash
        String dash = "—";
        String startTxt = (startWeight == null) ? dash : String.format(Locale.getDefault(), "%.1f", startWeight);
        String currTxt = (currentWeight == null) ? dash : String.format(Locale.getDefault(), "%.1f", currentWeight);
        String goalTxt = (goalWeight == 0.0) ? dash : String.format(Locale.getDefault(), "%.1f", goalWeight);
        String leftTxt = dash;

        if (currentWeight != null && goalWeight != 0.0) {
            double left = currentWeight - goalWeight;
            if (left < 0) left = 0;
            leftTxt = String.format(Locale.getDefault(), "%.1f", left);
        }
        // push text into the UI
        statStart.setText(startTxt);
        statCurrent.setText(currTxt);
        statGoal.setText( goalTxt);
        statRemaining.setText(leftTxt);
    }


    private void checkAndSendSMSIfEnabled() {
        DatabaseHelper.User user = dbHelper.getUser();
        if (user == null || user.phone == null || user.phone.isEmpty()) {
            return;
        }
        // read preference for SMS notifications
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(requireContext());
        boolean smsEnabled = prefs.getBoolean("sms_notifications", false);
        // only send SMS if user opted in AND app has SEND_SMS permission
        if (smsEnabled && ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            sendSMS(user.phone, "Congratulations! You've reached your goal weight!");
        }

    }
    // basic SMS send using default SmsManager
    private void sendSMS(String phoneNumber, String message) {
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNumber, null, message, null, null);
    }
}
