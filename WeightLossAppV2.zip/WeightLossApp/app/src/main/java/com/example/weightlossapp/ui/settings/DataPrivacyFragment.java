package com.example.weightlossapp.ui.settings;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.weightlossapp.R;
import com.example.weightlossapp.database.DatabaseHelper;

public class DataPrivacyFragment extends Fragment {

    private EditText oldPasswordInput, newPasswordInput;
    private DatabaseHelper dbHelper;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_data_privacy, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view,
                              @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        dbHelper = new DatabaseHelper(requireContext());

        oldPasswordInput = view.findViewById(R.id.oldPasswordInput);
        newPasswordInput = view.findViewById(R.id.newPasswordInput);

        view.findViewById(R.id.changePasswordButton).setOnClickListener(v -> {
            String oldPass = oldPasswordInput.getText().toString().trim();
            String newPass = newPasswordInput.getText().toString().trim();

            if (TextUtils.isEmpty(oldPass) || TextUtils.isEmpty(newPass)) {
                Toast.makeText(getContext(), "Please fill in both password fields", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean success = dbHelper.updateUserPassword(oldPass, newPass);
            if (success) {
                Toast.makeText(getContext(), "Password changed successfully", Toast.LENGTH_SHORT).show();
                oldPasswordInput.setText("");
                newPasswordInput.setText("");
            } else {
                Toast.makeText(getContext(), "Old password incorrect or error occurred", Toast.LENGTH_SHORT).show();
            }
        });

        view.findViewById(R.id.deleteAccountButton).setOnClickListener(v -> {
            boolean accountDeleted = dbHelper.deleteUserAccount();
            if (accountDeleted) {
                Toast.makeText(getContext(), "Account and all data deleted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getContext(), "No account found", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
