package com.example.weightlossapp.ui.logweight;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.weightlossapp.R;
import com.example.weightlossapp.database.DatabaseHelper;
import com.google.android.material.snackbar.Snackbar;
import com.prolificinteractive.materialcalendarview.CalendarDay;
import com.prolificinteractive.materialcalendarview.MaterialCalendarView;

import java.util.Locale;

public class LogWeightFragment extends Fragment {

    private MaterialCalendarView calendar;
    private EditText weightInput;
    private Button saveWeightButton;
    private DatabaseHelper dbHelper;

    // keys used to keep a "draft" in SharedPreferences
    private static final String PREFS = "log_weight_draft";
    private static final String KEY_DRAFT_WEIGHT = "draft_weight";
    private static final String KEY_DRAFT_YEAR  = "draft_year";
    private static final String KEY_DRAFT_MONTH = "draft_month"; // stored as 1–12
    private static final String KEY_DRAFT_DAY   = "draft_day";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_log_weight, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view,
                              @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        calendar         = view.findViewById(R.id.calendarView);
        weightInput      = view.findViewById(R.id.weightInput);
        saveWeightButton = view.findViewById(R.id.saveWeightButton);
        Button btnToday = view.findViewById(R.id.btnToday);

        dbHelper = new DatabaseHelper(requireContext());

        // Restore draft (weight + date)
        SharedPreferences sp = requireContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String draft = sp.getString(KEY_DRAFT_WEIGHT, "");
        if (!draft.isEmpty()) {
            weightInput.setText(draft);
            weightInput.setSelection(weightInput.getText().length());
        }

        int draftYear  = sp.getInt(KEY_DRAFT_YEAR,  -1);
        int draftMonth = sp.getInt(KEY_DRAFT_MONTH, -1); // 1–12 in storage
        int draftDay   = sp.getInt(KEY_DRAFT_DAY,   -1);

        if (draftYear != -1 && draftMonth != -1 && draftDay != -1) {
            CalendarDay restored = CalendarDay.from(draftYear, draftMonth, draftDay); // expects 1–12
            calendar.setCurrentDate(restored);
            calendar.setSelectedDate(restored);
        } else {
            CalendarDay today = CalendarDay.today();
            calendar.setCurrentDate(today);
            calendar.setSelectedDate(today);
        }

        // when the user presses "Done" on the keyboard, act like they pressed Save
        weightInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                saveWeightButton.performClick();
                return true;
            }
            return false;
        });

        // "Today" button just jumps calendar back to today's date
        if (btnToday != null) {
            btnToday.setOnClickListener(v -> {
                CalendarDay t = CalendarDay.today();
                calendar.setCurrentDate(t);
                calendar.setSelectedDate(t);
            });
        }

        // Save button logic
        saveWeightButton.setOnClickListener(v -> {
            String weightStr = weightInput.getText().toString().trim();
            if (TextUtils.isEmpty(weightStr)) {
                Toast.makeText(getContext(), R.string.please_enter_weight, Toast.LENGTH_SHORT).show();
                return;
            }

            final double weightVal;
            try {
                weightVal = Double.parseDouble(weightStr);
            } catch (NumberFormatException e) {
                Toast.makeText(getContext(), R.string.invalid_weight_value, Toast.LENGTH_SHORT).show();
                return;
            }
            // get currently selected day on calendar (fallback to today if none is selected)
            CalendarDay sel = calendar.getSelectedDate();
            if (sel == null) sel = CalendarDay.today();

            // MaterialCalendarVIew is 0-based → add +1 when formatting to ISO
            int year   = sel.getYear();
            int month1 = sel.getMonth() + 1;  // fix off-by-one
            int day    = sel.getDay();

            // build date string in ISO form "YYYY-MM-DD" for database
            String dateString = String.format(Locale.getDefault(), "%04d-%02d-%02d", year, month1, day);
            // insert into DB
            long rowId = dbHelper.addWeightEntry(dateString, weightVal);
            if (rowId != -1) {
                // Clear draft after successful save
                requireContext()
                        .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                        .edit()
                        .clear()
                        .apply();
                // show Snackbar with Undo button
                Snackbar.make(requireView(), R.string.weight_saved, Snackbar.LENGTH_LONG)
                        .setAction(R.string.undo, click -> {
                            dbHelper.deleteWeightEntry(rowId);
                            weightInput.setText(String.valueOf(weightVal));
                            weightInput.setSelection(weightInput.getText().length());
                        })
                        .show();

                weightInput.setText("");
            } else {
                Toast.makeText(getContext(), R.string.error_saving_weight, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onPause() {
        super.onPause();
        // save a draft of the current weight & selected date so it isn't lost if user leaves the screen
        SharedPreferences sp = requireContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        CalendarDay sel = calendar.getSelectedDate();
        if (sel == null) sel = CalendarDay.today();

        // Store month as 1–12 to avoid future off-by-one confusion
        sp.edit()
                .putString(KEY_DRAFT_WEIGHT, weightInput.getText().toString().trim())
                .putInt(KEY_DRAFT_YEAR,  sel.getYear())
                .putInt(KEY_DRAFT_MONTH, sel.getMonth() + 1)   // store 1–12
                .putInt(KEY_DRAFT_DAY,   sel.getDay())
                .apply();
    }
}
