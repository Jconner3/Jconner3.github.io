package com.example.weightlossapp.util;

import android.util.Base64;

import java.security.SecureRandom;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public final class CryptoUtil {
    private CryptoUtil() {
    }

    public static byte[] genSalt(int bytes) {
        byte[] s = new byte[bytes];
        new SecureRandom().nextBytes(s);
        return s;
    }

    public static String b64(byte[] x) {
        return Base64.encodeToString(x, Base64.NO_WRAP);
    }

    public static byte[] deB64(String s) {
        return Base64.decode(s, Base64.NO_WRAP);
    }

    /**
     * Derive a 256-bit key and return as Base64 chars (SQLCipher accepts char[] passphrases).
     */
    public static char[] derivePassphrase(String password, byte[] salt) {
        try {
            PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, 100_000, 256);
            SecretKeyFactory skf = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            byte[] key = skf.generateSecret(spec).getEncoded();
            return b64(key).toCharArray();
        } catch (Exception e) {
            throw new RuntimeException("Key derivation failed", e);
        }
    }
}
