package com.example.weightlossapp.database;

import java.util.Arrays;

public final class DbSession {
    private static char[] passphrase;

    private DbSession() {
    }

    public static void set(char[] p) {
        passphrase = p;
    }

    public static char[] get() {
        return passphrase;
    }

    public static void clear() {
        if (passphrase != null) Arrays.fill(passphrase, '\0');
        passphrase = null;
    }
}
